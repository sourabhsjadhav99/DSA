
let arr=[1,2,3,5,1,5,9,1,2,8];
let dupArr=[];
let len=arr.length;
for(let i=0;i<len;i++){
    if(dupArr.indexOf(arr[i])===-1){
        dupArr.push(arr[i]);
    }
}

console.log(dupArr);
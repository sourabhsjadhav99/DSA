function reverse(givenString, subStr) {
  return givenString.split(subStr).reverse().join(subStr);
}
let givenString = "Welcome to this Javascript Guide!";
let revStr = reverse(givenString, "");
let revWords = reverse(revStr, " ");
console.log(revWords);

